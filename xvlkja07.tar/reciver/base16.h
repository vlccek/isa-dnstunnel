//
// Created by jvlk on 11.11.22.
//

#ifndef BASE16_H
#define BASE16_H
unsigned char *tobase16(const unsigned char *in, int len);
unsigned char *frombase16(const unsigned char *in, int len);
#endif //BASE16_H
